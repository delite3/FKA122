int main()
{
    /* *******************************
     * 
     * Here is some code that is
     * using vector.c
     *
     * For an example look at the
     * third exercise
     *
     * ******************************/
    return 0;
}
