int
main()
{
    float stack_array[10000000];
    stack_array[0] = 0;
    return 0;
}
