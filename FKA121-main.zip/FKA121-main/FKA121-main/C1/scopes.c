#include <stdio.h>
    
int
main()
{
    
	int b = 1;
    
    printf("b: %i\n", b);
    return 0;
}
