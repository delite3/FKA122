extern int run(int argc, char *argv[]);

int
main(
     int argc,
     char *argv[]
    )
{
    /*********************************/
    /* Do not add any code here      */
    /* Add it in run instead         */
    /*********************************/
    return run(argc, argv);
}
