#ifdef __cplusplus
extern "C"
{
#endif

void nep_wrapper(int natoms, int *type, double *box, double *position, double *potential, double *force, double *virial);

#ifdef __cplusplus
}
#endif
