#pragma once
double scalarProduct(double* , double* ,int );
double computeDistance(double* , double* );

